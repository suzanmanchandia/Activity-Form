<html>
<body>
{{ $content }}
</body>
</html>