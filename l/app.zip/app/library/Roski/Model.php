<?php

namespace Roski;

abstract class Model extends \Eloquent {}